package com.example.form

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        databaseHelper = DatabaseHelper(this)

        val etName = findViewById<EditText>(R.id.etName)
        val etAge = findViewById<EditText>(R.id.etAge)
        val etHSC = findViewById<EditText>(R.id.etHSC)
        val etCity = findViewById<EditText>(R.id.etCity)
        val etAddress = findViewById<EditText>(R.id.etAddress)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)

        btnSubmit.setOnClickListener {
            val name = etName.text.toString().trim()
            val age = etAge.text.toString().trim()
            val hscPercentage = etHSC.text.toString().trim()
            val city = etCity.text.toString().trim()
            val address = etAddress.text.toString().trim()

            if (name.isEmpty() || age.isEmpty() || hscPercentage.isEmpty() || city.isEmpty() || address.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            } else {
                val isInserted = databaseHelper.insertUser(
                    name,
                    age.toInt(),
                    hscPercentage.toDouble(),
                    city,
                    address
                )
                if (isInserted) {
                    Toast.makeText(this, "Data Inserted Successfully", Toast.LENGTH_SHORT).show()
                    etName.text.clear()
                    etAge.text.clear()
                    etHSC.text.clear()
                    etCity.text.clear()
                    etAddress.text.clear()
                } else {
                    Toast.makeText(this, "Failed to Insert Data", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
